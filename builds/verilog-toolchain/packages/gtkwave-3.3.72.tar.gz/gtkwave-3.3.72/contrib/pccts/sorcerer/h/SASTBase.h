#ifndef SASTBase_h
#define SASTBase_h

#include "PCCTSAST.h"

typedef PCCTS_AST SORASTBase;

#endif
