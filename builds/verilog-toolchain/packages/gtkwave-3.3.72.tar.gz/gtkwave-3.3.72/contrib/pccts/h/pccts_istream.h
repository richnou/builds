#ifndef __PCCTS_ISTREAM_H__
#define __PCCTS_ISTREAM_H__

#ifdef PCCTS_USE_NAMESPACE_STD
#include <istream>
#else
#include <istream.h>
#endif

#endif
